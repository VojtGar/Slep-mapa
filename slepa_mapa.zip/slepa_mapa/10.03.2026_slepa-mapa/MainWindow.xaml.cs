﻿using System.Windows;
using System.Windows.Controls;

namespace _10._03._2026_slepa_mapa
{
    public partial class MainWindow : Window
    {
        List<MapPoint> points = new List<MapPoint>()
        {
            new MapPoint(){ Name="Brno", XPercent=0.6766, YPercent=0.7153 },
            new MapPoint(){ Name="Praha", XPercent=0.3476, YPercent=0.3942 },
            new MapPoint(){ Name="Ostrava", XPercent=0.8917, YPercent=0.4599 },
            new MapPoint(){ Name="Plzeň", XPercent=0.2050, YPercent=0.4500 },
            new MapPoint(){ Name="Liberec", XPercent=0.5500, YPercent=0.2000 }
        };

        MapPoint activePoint;
        Random rnd = new Random();

        int score = 0;
        int round = 0;
        int maxRounds = 10;

        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded;
        }

        void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            UpdateCanvasSize();
            DrawPoints();
            SetNextPoint();
        }

        private void MapImage_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            UpdateCanvasSize();
            DrawPoints();
        }

        void UpdateCanvasSize()
        {
            // 🔥 KLÍČOVÉ – Canvas má stejnou velikost jako skutečný obrázek
            OverlayCanvas.Width = MapImage.ActualWidth;
            OverlayCanvas.Height = MapImage.ActualHeight;
        }

        void DrawPoints()
        {
            OverlayCanvas.Children.Clear();

            foreach (var point in points)
            {
                double x = MapImage.ActualWidth * point.XPercent;
                double y = MapImage.ActualHeight * point.YPercent;

                Button btn = new Button()
                {
                    Content = "●",
                    Width = 30,
                    Height = 30,
                    Tag = point
                };

                btn.Click += Btn_Click;

                // 🔥 STŘED TLAČÍTKA NA SOUŘADNICI
                Canvas.SetLeft(btn, x - btn.Width / 2);
                Canvas.SetTop(btn, y - btn.Height / 2);

                OverlayCanvas.Children.Add(btn);
            }
        }

        void SetNextPoint()
        {
            if (round >= maxRounds)
            {
                MessageBox.Show($"Konec hry!\nSkóre: {score}/{maxRounds}");
                score = 0;
                round = 0;
            }

            activePoint = points[rnd.Next(points.Count)];
            QuestionText.Text = $"Najdi město: {activePoint.Name}";
            ScoreText.Text = $"Skóre: {score}/{round}";
        }

        private void Btn_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            MapPoint point = btn.Tag as MapPoint;

            round++;

            if (point.Name == activePoint.Name)
            {
                score++;
                btn.Background = System.Windows.Media.Brushes.LightGreen;
                MessageBox.Show("Správně!");
            }
            else
            {
                btn.Background = System.Windows.Media.Brushes.Red;
                MessageBox.Show($"Špatně! Bylo to: {activePoint.Name}");
            }

            SetNextPoint();
        }
    }
}